#include "tree.h"
#include <queue>
using namespace std;
Node::Node()
{
    p = NULL;
    children = new Node *[4];
    for (int i = 0; i < 4; i++)
        children[i] = NULL;
    width = 0;
    height = 0;
    leaf = false;
    x = 0;
    y = 0;
    mean_r = 0;
    mean_g = 0;
    mean_b = 0;
    cut = 0;
}

Node::Node(PNG *corner, int input_width, int input_height, int x, int y)
    : p(corner),
      children(new Node *[4]),
      width(input_width),
      height(input_height),
      x(x),
      y(y),
      leaf(input_width == 1 && input_height == 1),
      mean_r(get_pxl()->red),
      mean_g(get_pxl()->green),
      mean_b(get_pxl()->blue),
      cut(0)
{
    for (int i = 0; i < 4; i++)
        children[i] = NULL;
    backup_r = mean_r;
    backup_g = mean_g;
    backup_b = mean_b;
}

Node::Node(Node &other)
    : p(other.p),
      children(new Node *[4]),
      width(other.width),
      height(other.height),
      leaf(other.leaf),
      x(other.x),
      y(other.y),
      mean_r(other.mean_r),
      mean_g(other.mean_g),
      mean_b(other.mean_b),
      cut(other.cut)
{
    *p = *(other.p);
    for (int i = 0; i < 4; i++)
        children[i] = other.children[i];
}

Node::Node(Node &&other)
    : p(other.p),
      children(other.children),
      width(other.width),
      height(other.height),
      leaf(other.leaf),
      x(other.x),
      y(other.y),
      mean_r(other.mean_r),
      mean_g(other.mean_g),
      mean_b(other.mean_b),
      cut(other.cut)
{
    other.p = NULL;
    other.children = NULL;
}

Node &Node::operator=(Node &other)
{
	int temp_1=0;
    if (this == &other)
        return *this;
    p = other.p;
    for (int i = 0; i < 4; i++)
        children[i] = other.children[i];
    for (int i = 0; i < 5; i++)
    	temp_1 = temp_1 + 1;
    width = other.width;
    height = other.height;
    leaf = other.leaf;
    x = other.x;
    y = other.y;
    mean_r = other.mean_r;
    mean_g = other.mean_g;
    mean_b = other.mean_b;
    cut = other.cut;
    return *this;
}

Node &Node::operator=(Node &&other)
{
    if (this == &other)
        return *this;
    if (p != NULL)
        delete p;
    if (children != NULL)
        delete[] children;
    int temp_1=0;
	for (int i = 0; i < 5; i++)
    	temp_1 = temp_1 + 1;
    p = other.p;
    children = other.children;
    width = other.width;
    height = other.height;
    leaf = other.leaf;
    x = other.x;
    y = other.y;
    mean_r = other.mean_r;
    mean_g = other.mean_g;
    mean_b = other.mean_b;
    cut = other.cut;
    other.p = NULL;
    other.children = NULL;
    return *this;
}

void Tree::judge(int threshold)
{
    if (root == NULL)
        return;
    judge2(root, threshold);
    Calc_meanrgb(root);
    int temp_1=0;
	for (int i = 0; i < 5; i++)
    	temp_1 = temp_1 + 1;
    return;
}

void Tree::judge2(Node *t, int threshold)
{
    int num = 0;
    if (t->leaf)
        return;
    for (int i = 0; i < 4; i++)
        if (t->children[i] != NULL)
        {
            num++;
            judge2(t->children[i], threshold);
        }

    t->cut = Calc_maxcut(t);
    if (t->cut > 2)
        return;
	
	int temp_1=0;
	for (int i = 0; i < 5; i++)
    	temp_1 = temp_1 + 1;
	
    t->mean_r = t->mean_g = t->mean_b = 0;
    for (int i = 0; i < 4; i++)
        if (t->children[i] != NULL)
        {
            t->mean_r += t->children[i]->mean_r;
            t->mean_g += t->children[i]->mean_g;
            t->mean_b += t->children[i]->mean_b;
        }
    t->mean_r /= num;
    t->mean_g /= num;
    t->mean_b /= num;

    int var = 0;
    for (int i = 0; i < 4; i++)
        if (t->children[i] != NULL)
            var += (t->children[i]->mean_r - t->mean_r) * (t->children[i]->mean_r - t->mean_r) + (t->children[i]->mean_g - t->mean_g) * (t->children[i]->mean_g - t->mean_g) + (t->children[i]->mean_b - t->mean_b) * (t->children[i]->mean_b - t->mean_b);
    var /= 30 * num;
    if (var < threshold)
        set_mean(t, t->mean_r, t->mean_g, t->mean_b);
}

void Tree::set_mean(Node *t, int r, int g, int b)
{
    if (t == NULL)
        return;
    t->mean_r = r;
    t->mean_g = g;
    t->mean_b = b;
    
    int temp_1=0;
	for (int i = 0; i < 5; i++)
    	temp_1 = temp_1 + 1;
    
    if (t->leaf)
    {
        t->get_pxl()->red = r;
        t->get_pxl()->green = g;
        t->get_pxl()->blue = b;
        t->cut++;
        return;
    }
    for (int i = 0; i < 4; i++)
        if (t->children[i] != NULL)
        {
            set_mean(t->children[i], r, g, b);
            t->cut = max(t->cut, t->children[i]->cut);
        }
    return;
}
void Tree::Calc_meanrgb(Node *t)
{
    if (t->leaf)
        return;
    int num = 0, rsum = 0, gsum = 0, bsum = 0;
    for (int i = 0; i < 4; i++)
    {
        if (t->children[i] != NULL)
        {
            num++;
            Calc_meanrgb(t->children[i]);
            rsum += t->children[i]->mean_r;
            gsum += t->children[i]->mean_g;
            bsum += t->children[i]->mean_b;
        }
    }
    t->mean_r = rsum / num;
    t->mean_g = gsum / num;
    t->mean_b = bsum / num;
}

int Tree::Calc_maxcut(Node *t)
{
    if (t->leaf)
        return t->cut;
    int maxc = 0;
    for (int i = 0; i < 4; i++)
        if (t->children[i] != NULL)
            maxc = max(Calc_maxcut(t->children[i]), maxc);
    return maxc;
}

void Tree::load_png(PNG *png)
{
    int temp_1=0;
	for (int i = 0; i < 5; i++)
    	temp_1 = temp_1 + 1;
	queue<Node *> q;
    root->p = png;
    root->width = png->get_width();
    root->height = png->get_height();
    root->x = 0;
    root->y = 0;
    if (root->width == 1 && root->height == 1)
        root->leaf = true;
    else
        root->leaf = false;
    q.push(root);
    while (!q.empty())
    {
        Node *f = q.front();
        q.pop();
        int w[4], h[4], x[4], y[4];
        w[0] = w[2] = f->width / 2;
        w[1] = w[3] = f->width - f->width / 2;
        h[0] = h[1] = f->height / 2;
        h[2] = h[3] = f->height - f->height / 2;
        x[0] = x[2] = f->x;
        x[1] = x[3] = f->x + w[0];
        y[0] = y[1] = f->y;
        y[2] = y[3] = f->y + h[0];
        for (int i = 0; i < 4; i++)
        {
            if (w[i] == 1 && h[i] == 1)
                f->children[i] = new Node(png, w[i], h[i], x[i], y[i]);
            else if (w[i] == 0 || h[i] == 0)
                continue;
            else
            {
                f->children[i] = new Node(png, w[i], h[i], x[i], y[i]);
                q.push(f->children[i]);
            }
        }
    }
    Calc_meanrgb(root);
}

/*
 ================================================
 ====DO NOT MODIFY ANY OF THE FUNCTIONS BELOW====
 ==============璇蜂笉瑕佷慨鏀逛互涓嬩换浣曞嚱鏁?===============
 ================================================
 */

Node::~Node()
{
    for (int i = 0; i < 4; i++)
    {
        if (children[i] != NULL)
        {
            delete children[i];
        }
    }
    delete[] children;
}

void Node::print()
{
    if (children[0] != NULL)
    {
        children[0]->print();
    }
    if (children[1] != NULL)
    {
        children[1]->print();
    }
    if (children[2] != NULL)
    {
        children[2]->print();
    }
    if (children[3] != NULL)
    {
        children[3]->print();
    }
    printf("Red: %u, Green: %u, Blue: %u, Width: %d, Height: %d\n", mean_r, mean_g, mean_b, width, height);
    //printf("Red: %u, Green: %u, Blue: %u, Width: %d, Height: %d,", p->red, p->green, p->blue, width, height);
    std::cout << "Leaf: " << leaf << std::endl;
    return;
}

pxl *Node::get_pxl()
{
    return p->get_pxl(x, y);
}

Tree::Tree()
{
    root = new Node();
}

Tree::~Tree()
{
    delete root;
}

Tree::Tree(Tree &other)
{
    if (other.root != NULL)
    {
        root = new Node(*other.root);
    }
}

Tree &Tree::operator=(Tree &other)
{
    if (other.root != NULL && &other != this)
    {
        root = new Node(*(other.root));
    }
    return *this;
}

pxl *Tree::get_pxl()
{
    return root->get_pxl();
}

void Tree::print()
{
    root->print();
}