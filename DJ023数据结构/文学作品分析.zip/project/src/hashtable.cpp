#include "hashtable.h"

bool Node::operator!=(const char *str) {
    if(str == NULL)
        return false;
    string temp = str;
    if(temp != p.first)
        return true;
    else
        return false;
}

bool Node::operator!=(const string &str) {
    if(str == p.first)
        return true;
    else
        return false;
}

bool Node::operator==(const char *str) {
    if(str == NULL)
        return false;
    string temp = str;
    if(temp == p.first)
        return true;
    else
        return false;
}

bool Node::operator==(const string &str) {
    if(str == p.first)
        return true;
    else
        return false;
}

bool Node::operator!=(Node &n) {
    if(n.p.first == p.first)
        return true;
    else
        return false;
}

bool Node::operator==(Node &n) {
    if(n.p.first == p.first)
        return true;
    else
        return false;
}

char Node::operator[](const int index) {
    char a=p.first[index];
    return a;
}

int Node::length() { //return length of the string
    return p.first.length();
}

int &Node::second() {
    return p.second;
}

const pair<string, int>* Node::get_pair() const {
    const pair<string, int>* T = &p;
    return T;
}

Node::~Node() {
}

HashTable::HashTable() {
    elem = new Node[MAXN];
    for (int i = 0; i < MAXN; i++)
    {
        Node T;
        T.second() = 0;
        elem[i] = T;
    }
    size = MAXN;
}

HashTable::~HashTable() {
    delete[] elem;
}

int HashTable::hash(Node &index) {
    int length = index.length();
    long long ans = 0;
    for (int i = 0; i < length; i++)
        ans += 1 << (tolower(index.get_pair()->first[i]) - 'a');
    return (ans + 7) % MAXN;
}

bool HashTable::search(Node &index, int &pos, int &times) {
    int res = hash(index);
    pos = res;
    times = 0;
    for (int i = res; times < MAXN; i = (i + 1) % MAXN)
    {
        if (elem[i] == index)
        {
            pos = i;
            return true;
        }
        else if (elem[i].get_pair()->second == 0)
        {
            pos = i;
            return false;
        }
        else
            times++;
    }
    pos = -1;
    return false;
}

int HashTable::insert(Node &index) {
    int pos_1, times_1;
    if (search(index, pos_1, times_1))
    {
        elem[pos_1].second()++;
        return 2;
    }
    else if (pos_1 >= 0)
    {
        elem[pos_1] = index;
        elem[pos_1].second() = 1;
        return 1;
    }

    return -1;
}

int HashTable::insert(const char * str) {
    int pos_2, times_2;
    Node index(str);
    if (search(index, pos_2, times_2))
    {
        elem[pos_2].second()++;
        return 2;
    }
    elem[pos_2] = index;
    elem[pos_2].second() = 1;
    return 1;
}

/*
 ==========================================================================
 =================Please Do Not Modify Functions Below=====================
 ========================请不要修改下列函数实现================================
 ==========================================================================
 */

Node::Node() {
    p = make_pair(string("#"), 1);
}

Node::Node(const char *str) {
    p = make_pair(string(str), 1);
}

Node::Node(const string &str) {
    p = make_pair(str, 1);
}

int HashTable::get_size() const {
    return size;
}

const pair<string, int>* HashTable::get_pair(int index) {
    if (index < size && index >= 0) {
        return (elem[index].get_pair());
    }
    return NULL;
}

const pair<string, int>* HashTable::get_pair(int index) const {
    if (index < size && index >= 0) {
        return (elem[index].get_pair());
    }
    return NULL;
}
