#include "hashtable.h"
#include "dict.h"
#include <iostream>
#include <stdlib.h>
#include <string.h>
#include <fstream>
#include <sstream>

int read_from_file(FILE *input_file, Dict *d);
string findNextWord(FILE *input_file);
int main(int argc, char *argv[])
{
    if (argc != 2)
    {
        exit(1);
    }
    FILE *input = fopen(argv[1], "r");
    if (input == 0)
    {
        perror("Fopen Failed ");
        exit(-1);
    }
    Dict d = Dict();
    read_from_file(input, &d);
    fclose(input);
    d.print();
    return 0;
}

int read_from_file(FILE *input_file, Dict *d)
{
    string s;
    while (true)
    {
        s = findNextWord(input_file);
        if (s.empty())
            break;
        d->insert(s.c_str());
    }
    return 0;
}
string findNextWord(FILE *input_file)
{
    string T;
    char a;
    while ((a = fgetc(input_file)) != EOF)
    {

        if (isalpha(a))
            a = tolower(a);
        if (T.empty())
            if (isalpha(a))
                T += a;
            else
                continue;
        else if (isalpha(a))
            T += a;
        else
            break;
    }
    return T;
}