#include "workflow.h"
#include "vector.h"
#include "worker.h"
#include <iostream>

Job::~Job()
{
	if (worker)
		delete worker;
	prev = next = NULL; //TODO
}

Workflow::Workflow()
{
	head = tail = NULL;
	size = 0; //TODO
}

Workflow::~Workflow()
{
	Job *p = NULL;
	while (head != NULL)
	{
		p = head;
		head = head->next;
		delete p;
		if (head != NULL)
			head->prev = NULL;
	}
	//TODO
}

int Workflow::insert(Job *j)
{
	if (j == NULL)
		return 1;
	j->next = NULL;
	if (head == NULL)
	{
		head = tail = j;
		head->prev = tail->next = NULL;
	}
	else
	{
		j->prev = tail;
		tail->next = j;
		tail = j;
	}
	size++;
	//TODO
	return 0;
}

int Workflow::swap(int original_index, int target_index)
{
	if (original_index < 0 || original_index >= size || target_index < 0 || target_index >= size||original_index==target_index)
		return 1;
	Job *j, *h;
	j = h = head;
	int flag1 = 0, flag2 = 0;
	while (!(flag1 == original_index && flag2 == target_index))
	{
		if (flag1 != original_index)
		{
			j = j->next;
			flag1++;
		}
		if (flag2 != target_index)
		{
			h = h->next;
			flag2++;
		}
	}
	Job *j1, *j2;
	j1 = j->next;
	j2 = h->next;
	j->next = j2;
	h->next = j1;
	if (j1 != NULL)
		j1->prev = h;
	else
		tail = h;
	if (j2 != NULL)
		j2->prev = j;
	else
		tail = j;
	j1 = j->prev;
	j2 = h->prev;
	j->prev = j2;
	h->prev = j1;
	if (j1 != NULL)
		j1->next = h;
	else
		head = h;
	if (j2 != NULL)
		j2->next = j;
	else
		head = j;
	return 0;
}

Job *Workflow::pop()
{
	if (size==0)
		return NULL;
	Job *j = head;
	head = j->next;
	if(head)	head->prev = NULL;
	size--;
	j->next = NULL;
	return j; //TODO
}

int Workflow::process(vector *l, int index)
{
	if (l == NULL || index < 0 || index >= size || size == 0)
		return 1;
	Worker *w = l->remove(0);
	if (!w)	return 1;
	int flag = 0;
	Job *j = head;
	while (flag != index)
	{
		j = j->next;
		flag++;
	}
	if (!j)	return 1;
	if (j->worker != NULL)
		delete j->worker;
	j->worker = w;
	//TODO
	return 0;
}

/*预警：以下内容不许修改。*/
int Job::num_job = 0; //Do not remove or modify this line.
					  //警告：你不可以改动这一行！
Job::Job()
{ //警告：你不可以改动这个函数！
	id = num_job;
	num_job++;
	next = NULL;
	prev = NULL;
	worker = NULL;
}
int Workflow::print()
{ //警告：你不可以改动这个函数！
	Job *curr = head;
	int i = 0;
	if (curr == NULL)
	{
		std::cout << "Empty Flow\n";
		return 0;
	}
	while (curr != NULL)
	{
		std::cout << "[" << i << "]";
		curr->print();
		i++;
		curr = curr->next;
	}
	return 0;
}
int Job::print()
{
	std::cout << "job [" << this->id << "]\n";
	return 0;
}