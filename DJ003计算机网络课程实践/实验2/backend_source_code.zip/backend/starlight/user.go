package starlight

import (
	"encoding/json"
	"log"
	"math/rand"
	"strconv"
	"strings"
	"time"
)

// OnLogin 登陆
func (c *Client) OnLogin() error {

	// 接收用户的消息头
	_, message, err := c.Conn.ReadMessage()
	if err != nil {
		return err
	}

	// 解析用户消息
	in := UserInfo{}
	err = json.Unmarshal(message, &in)
	if err != nil {
		return err
	}
	log.Printf("userinfo %v", in)
	c.Info = in
	// if in.ContentType != 1001 {
	// 	// 刚开始不是登陆请求直接进行错误处理并且返回
	// 	return errors.New("连接后的第一个请求不是登陆请求")
	// }
	//
	// if in.UserInfo.UserID == "" {
	// 	in.UserInfo.UserID = RandString(32)
	// }
	//
	// fmt.Println(in.UserInfo.UserID, "加入概率论")
	//
	// c.Info = in.UserInfo
	//
	// // 建立用户名和客户端的唯一连接
	// c.Hub.UserToClient[in.UserInfo.UserID] = c
	//
	// baseRes := BaseMessage{
	// 	ContentType: 1002,
	// 	Msg:         "登陆成功",
	// 	UserInfo:    in.UserInfo,
	// }

	// mess, err := json.Marshal(&baseRes)
	// if err != nil {
	// 	return err
	// }

	// 回复注册
	// c.Send <- message

	return nil
}

func RandString(length int) string {
	rand.Seed(time.Now().UnixNano())
	rs := make([]string, length)
	for start := 0; start < length; start++ {
		t := rand.Intn(3)
		if t == 0 {
			rs = append(rs, strconv.Itoa(rand.Intn(10)))
		} else if t == 1 {
			rs = append(rs, string(rand.Intn(26)+65))
		} else {
			rs = append(rs, string(rand.Intn(26)+97))
		}
	}
	return strings.Join(rs, "")
}
