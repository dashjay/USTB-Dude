/**
 * 该文件处理的数据交换中心，储存所有连接并且保存其状态的的用户,创建了用户和连接的唯一关系，广播消息队列。注册队列，和注销队列，保存群组等功能。
 */
package starlight

import (
	log "github.com/sirupsen/logrus"
)

// 整个项目的交流系统，由clients和各种不同的chan组成，
type Hub struct {
	Clients      map[*Client]bool   // 储存保持连接的用户
	UserToClient map[string]*Client // 获得用户和其连接的对应关系
	WaitForMatch map[*Client]bool   //
	Message      chan []byte        // 广播消息队列
	Register     chan *Client       // 发起注册请求的队列
	Unregister   chan *Client       // 断开连接的队列

}

func NewHub() *Hub {
	return &Hub{
		Message:      make(chan []byte),        // 消息队列
		Register:     make(chan *Client),       // 等待创建连接的用户
		Unregister:   make(chan *Client),       // 等待退出断开连接的用户
		Clients:      make(map[*Client]bool),   // 客户数组
		UserToClient: make(map[string]*Client), // 建立用户名和客户端唯的唯一通道
		WaitForMatch: make(map[*Client]bool),
	}
}

// Run 跑起来，完成和用户保持连接，注册，注销用户等功能，控制消息队列
func (h *Hub) Run() {
	for {
		select {

		case client := <-h.Register: // 用户创建新的连接
			{
				h.Clients[client] = true
				log.Infoln("当前在线人数:", len(h.Clients))
			}

		case client := <-h.Unregister: // 用户断开连接
			{
				if _, ok := h.Clients[client]; ok {
					delete(h.Clients, client)
					close(client.Send)
				}
				log.Infoln(client.Info.Nickname, "断开连接")
				log.Infoln("当前在线人数:", len(h.Clients))
				// 将用户名和连接之间的唯一关系删除
				// delete(h.UserToClient, client.Info.UserID)
				delete(h.WaitForMatch, client)
			}
		// 这个是全局消息 每个人都会收到
		case message := <-h.Message:
			{
				for client := range h.Clients {
					select {
					case client.Send <- message:
					default:
						close(client.Send)
						delete(h.Clients, client)
					}
				}
			}
		}
	}
}
