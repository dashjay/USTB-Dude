// Copyright 2013 The Gorilla WebSocket Authors. All rights reserved.
// Use of this source code is governed by a BSD-style

// license that can be found in the LICENSE file.

/**
 * client文件中声明了Client客户端这个结构以及有关其的一系列操作
 * 都是针对个人（客户端）的操作
 * 例如：1. Pong回复客户端Ping消息
 * 		2. 从客户端读取消息和向客户端写入消息
 * 		3. 将本客户端连接写入群组中
 * TODO	4. 此处应该写各种消息类型的handler
 *
 */
package starlight

import (
	"fmt"
	"time"

	log "github.com/sirupsen/logrus"

	"github.com/gorilla/websocket"
)

const (
	// Time allowed to write a message to the peer.
	writeWait = 10 * time.Second

	// Time allowed to read the next pong message from the peer.
	pongWait = 5 * time.Second

	// Send pings to peer with this period. Must be less than pongWait.
	pingPeriod = (pongWait * 9) / 10

	// Maximum message size allowed from peer.
	maxMessageSize = 1024
)

type UserInfo struct {
	Nickname string `json:"nickname"`
	Gender   int32  `json:"gender"`
	Avatar   string `json:"avatar"`
}

// Client 是Websocket和Hub(收发机)的中间人
type Client struct {
	Hub  *Hub            // 管理全局消息的中枢
	Conn *websocket.Conn // The websocket connection.
	Send chan []byte     // 预备发送的消息队列
	Info UserInfo        // 用户信息
}

// ReadPump 从Websocket连接中泵出消息，发送到Hub中
// 应用在每个Websocket连接上运行一个 goroutine.
func (c *Client) ReadPump() {
	// 函数返回后执行内容
	defer func() {
		c.Hub.Unregister <- c
		_ = c.Conn.Close()
	}()

	// 设置读限制
	c.Conn.SetReadLimit(maxMessageSize)
	// read超时时间
	_ = c.Conn.SetReadDeadline(time.Now().Add(pongWait))
	// 超时操作
	c.Conn.SetPongHandler(func(string) error {
		_ = c.Conn.SetReadDeadline(time.Now().Add(pongWait))
		return nil
	})

	// 第一个消息就是处理注册
	if err := c.OnLogin(); err != nil {
		fmt.Println("注册失败,", err.Error())
	}
	for {
		// 读取消息
		_, message, err := c.Conn.ReadMessage()

		if err != nil {
			if websocket.IsUnexpectedCloseError(err, websocket.CloseGoingAway, websocket.CloseAbnormalClosure) {
				log.Printf("error: %v", err)
			}
			break
		}
		c.Hub.Message <- message
	}
}

// WritePump 从Hub获取内容发送到客户端
// 协程保证每一条消息都发送到客户端
func (c *Client) WritePump() {
	ticker := time.NewTicker(pingPeriod)
	defer func() {
		ticker.Stop()
		_ = c.Conn.Close()
	}()

	// 发送消息的队列
	for {
		select {
		case message, ok := <-c.Send:
			_ = c.Conn.SetWriteDeadline(time.Now().Add(writeWait))
			if !ok {
				// The hub closed the channel.
				_ = c.Conn.WriteMessage(websocket.CloseMessage, []byte{})
				return
			}
			// TODO:这里是一个发送内容需要指定的Writer
			w, err := c.Conn.NextWriter(websocket.TextMessage)
			if err != nil {
				return
			}
			// 发送取出的第一条消息
			_, _ = w.Write(message)

			// 将队列中的消息全都发送出来
			n := len(c.Send)
			for i := 0; i < n; i++ {
				_, _ = w.Write(<-c.Send)
			}

			// 差错
			if err := w.Close(); err != nil {
				return
			}
		case <-ticker.C:
			_ = c.Conn.SetWriteDeadline(time.Now().Add(writeWait))
			if err := c.Conn.WriteMessage(websocket.PingMessage, nil); err != nil {
				return
			}
		}
	}
}
