package starlight

import "encoding/json"

type Message struct {
	MessageType int    `json:"message_type"`
	FromUserID  string `json:"from_user_id" bson:"from_user_id"`
	ToUserID    string `json:"to_user_id" bson:"to_user_id"`
	Content     string `json:"content" bson:"content"`
	Time        string `json:"time"`
}

type BaseMessage struct {
	ContentType int      `json:"content_type"`
	Msg         string   `json:"msg"`
	UserInfo    UserInfo `json:"user_info"`
	Message     Message  `json:"message"`
}

func (b *BaseMessage) PreSend() []byte {
	preSend, _ := json.Marshal(b)
	return preSend
}
