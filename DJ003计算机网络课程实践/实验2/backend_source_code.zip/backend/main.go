package main

import (
	"flag"
	"fmt"
	"net/http"

	log "github.com/sirupsen/logrus"

	"main/env"
	"main/starlight"
	"main/wshandler"
)

func main() {

	// 开始配置
	var addr = flag.String("addr", "3334", "http service address")
	// 解析
	flag.Parse()

	// 初始化配置
	env.Init()

	// 创建端系统的hub
	hub := starlight.NewHub()
	// 运行hub
	go hub.Run()

	// 监听消息
	http.HandleFunc("/ws", func(w http.ResponseWriter, r *http.Request) {
		wshandler.ServeWs(hub, w, r)
	})
	log.Printf("star light 启动 %s", *addr)
	err := http.ListenAndServe(fmt.Sprintf(":%s", *addr), nil)
	if err != nil {
		log.Fatal("ListenAndServe: ", err)
	}
}
