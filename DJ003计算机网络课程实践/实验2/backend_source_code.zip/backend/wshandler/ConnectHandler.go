package wshandler

import (
	"net/http"

	"github.com/gorilla/websocket"
	log "github.com/sirupsen/logrus"

	"main/starlight"
)

var upgrader = websocket.Upgrader{
	ReadBufferSize:  1024,
	WriteBufferSize: 1024,
	CheckOrigin:     func(r *http.Request) bool { return true },
}

// serveWs handles websocket requests from the peer.
func ServeWs(hub *starlight.Hub, w http.ResponseWriter, r *http.Request) {
	// 完成之后将http请求升级成socket连接
	conn, err := upgrader.Upgrade(w, r, nil)
	if err != nil {
		log.Println(err)
		return
	}
	// 初始化该用户
	c := &starlight.Client{Hub: hub, Conn: conn, Send: make(chan []byte, 256)}
	// 连接注册
	hub.Register <- c

	go c.ReadPump()
	go c.WritePump()
}
