<template>
	<view>
		<view class="cu-chat" style="padding-top: 100rpx;">
			<view :key="message.id" :class="'cu-item '+(message.self?'self':'')" v-for="message in MessageLists">
				<view class="cu-avatar radius" :style="'background-image:url(https://kustlove-1256941979.cos.ap-chengdu.myqcloud.com/avatars/'+(message.userinfo.gender?'boys/':'girls/')+(message.userinfo.gender?'boy':'girl')+message.userinfo.avatar +'.jpg);'"></view>
				<view class="main">
					<view class="content bg-green shadow">
						<text>{{message.content}}</text>
					</view>
					<view class="action text-grey">
						<text class="text-sm margin-left-sm">{{message.userinfo.nickname}}</text>
					</view>
				</view>
			</view>

			<view class="cu-bar foot input" :style="[{bottom:InputBottom+'px'}]">
				<view class="action">
					<text class="cuIcon-sound text-grey"></text>
				</view>
				<input class="solid-bottom" v-model="content" :adjust-position="false" :focus="false" maxlength="300"
				 :cursor-spacing="10" @focus="InputFocus" @blur="InputBlur"></input>
				<view class="action">
					<text class="cuIcon-emojifill text-grey"></text>
				</view>
				<button class="cu-btn bg-green shadow" @click="Send()">发送</button>
			</view>

		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				MessageLists: [{
					content: "以上消息不可恢复",
					userinfo: {
						user_id: 0,
						nickname: '小助手',
						gender: 1,
						avatar: 3,
					}
				}],
				InputBottom: 0,
				content: "",
				base_data: {
					content_type: -1, //ID
					user_id: "" // 外部的用户id
				},
				userinfo: {},
			};
		},
		onLoad(options) {
			let that = this;
			let userinfo = JSON.parse(options.userinfo);
			that.userinfo = userinfo;

			uni.onSocketOpen(function() {
				uni.sendSocketMessage({
					data: JSON.stringify(that.userinfo),
				})
			})
			uni.onSocketMessage(function(e) {
				let msg = JSON.parse(e.data);
				that.MessageLists.push(msg);
				uni.pageScrollTo({
					scrollTop: 9999999,
					duration: 300
				});
			})

			uni.connectSocket({
				url: "ws://134.175.38.159:3334/ws",
				// 连接成功
				success: (res) => {
					uni.showToast({
						title: "连接服务器成功"
					})
				},
				fail: (err) => {
					console.log(err)
					uni.showToast({
						title: "连接服务器失败，请刷新稍后重试",
						icon: "none"
					})
				}
			})
		},
		onBackPress() {
			uni.closeSocket({
				code: 1000
			})
		},
		methods: {
			InputFocus(e) {
				this.InputBottom = e.detail.height
			},
			InputBlur(e) {
				this.InputBottom = 0
			},
			Send() {
				// 规避空消息
				if (this.content == "") {
					uni.showToast({
						title: "不允许发送空消息",
						icon: "none"
					})
					return
				}
				let data = {
					content: this.content,
					userinfo: this.userinfo,
				}
				// this.MessageLists.push(data);
				uni.sendSocketMessage({
					data: JSON.stringify(data),
				});
				this.content = "";
			}
		},
		computed: {

		}
	}
</script>

<style>
	page {
		padding-bottom: 100upx;
	}
</style>
