<template>
	<view>
		<!-- <cu-custom bgColor="bg-gradual-blue" :isBack="false">
			<block slot="content">概率论|送本科生的礼物</block>
		</cu-custom> -->

		<view class="cu-bar bg-white solid-bottom margin-top">
			<view class="action">
				<text class="cuIcon-title text-orange "> 消息列表</text>
			</view>
		</view>

		<view class="cu-list menu-avatar">

			<view class="cu-form-group">
				<view class="title">配置列表</view>
			</view>

			<view class="cu-item" @tap="EditAvatar">
				<svg t="1575129750890" class="cu-avatar round lg" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg"
				 p-id="4176" width="200" height="200">
					<path d="M509.979 959.316c-247.308 0-447.794-200.486-447.794-447.794S262.671 63.728 509.979 63.728s447.794 200.486 447.794 447.794-200.485 447.794-447.794 447.794z m0-814.171c-202.346 0-366.377 164.031-366.377 366.377s164.031 366.377 366.377 366.377c202.342 0 366.377-164.031 366.377-366.377S712.321 145.145 509.979 145.145z m-40.708 610.628c-40.709 0-40.709-40.708-40.709-40.708l40.709-203.543s0-40.709-40.709-40.709c0 0-40.709 0-40.709-40.709h122.126s40.709 0 40.709 40.709-40.709 162.834-40.709 203.543 40.709 40.709 40.709 40.709h40.709c-0.001 0-0.001 40.708-122.126 40.708z m81.417-407.085c-22.483 0-40.709-18.225-40.709-40.709s18.225-40.709 40.709-40.709 40.709 18.225 40.709 40.709-18.226 40.709-40.709 40.709z"
					 p-id="4177"></path>
					<view class="cu-tag badge">1</view>
				</svg>

				<view class="content">
					<view class="text-grey">1. 点我修改头像</view>
					<view class="text-gray text-sm flex">
						<view class="text">
							<!-- <text class="cuIcon-infofill text-red  margin-right-xs"></text> -->
							点击下方概率论，随机聊天
						</view>
					</view>
				</view>

				<view class="action">
					<view class="text-grey text-xs">天下有情人终99</view>
					<view class="cu-tag round bg-red sm">99</view>
				</view>
			</view>

			<view class="padding-sm" v-show="avatars_show">
				<view @tap="chooseAvatar" :data-aid="item" class="cu-avatar round lg margin-xs" :style="'background-image:url(https://kustlove-1256941979.cos.ap-chengdu.myqcloud.com/avatars/'+(userinfo.gender==1?'boys/':'girls/')+(userinfo.gender==1?'boy':'girl')+item +'.jpg);'"
				 v-for="(item,index) in avatars_list" :key="index">
				</view>
			</view>

			<view class="cu-item" @tap="EditUsername">
				<view class="cu-avatar round lg" :style="'background-image:url(https://kustlove-1256941979.cos.ap-chengdu.myqcloud.com/avatars/'+(userinfo.gender?'boys/':'girls/')+(userinfo.gender?'boy':'girl')+userinfo.avatar+'.jpg);'">
				</view>
				<view class="content">
					<view class="text-grey">{{userinfo.nickname}}</view>
					<view class="text-gray text-sm flex">
						<view class="text-cut">
							<!-- <text class="cuIcon-infofill text-red  margin-right-xs"></text> -->
							快取一个帅气的名字，一起来和大家聊天吧~
						</view>
					</view>
				</view>
				<view class="action">
					<view class="action">
						<view class="text-grey text-xs">天下有情人终99</view>
						<view class="cu-tag round bg-red sm">99</view>
					</view>
				</view>
			</view>
			<view class="cu-form-group" v-show="editor_show">
				<view class="title">输入昵称</view>
				<input placeholder="请输入一个文明的名字" v-model="userinfo.nickname" name="input"></input>
				<button class='cu-btn bg-green shadow' @click="make_nickname">确定</button>
			</view>
			<view class="cu-form-group">
				<view class="title">聊天列表</view>
			</view>

			<view class="cu-item" @tap="GoChat">
				<svg t="1575128878867" class="cu-avatar round lg" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg"
				 p-id="1358" width="200" height="200">
					<path d="M513.033 512.578m-448.821 0a448.821 448.821 0 1 0 897.642 0 448.821 448.821 0 1 0-897.642 0Z" fill="#76C2AF"
					 p-id="1359"></path>
					<path d="M757.434 339.373L565.122 228.339c-27.942-16.135-76.237-16.135-104.179 0L268.632 339.373c-28.722 16.58-52.096 57.055-52.096 90.228v222.054c0 33.174 23.374 73.648 52.096 90.228l192.312 111.034c13.971 8.067 32.469 12.512 52.089 12.512 19.621 0 38.118-4.445 52.089-12.512l192.312-111.034c28.722-16.58 52.096-57.055 52.096-90.228V429.602c0-33.174-23.374-73.648-52.096-90.229z"
					 fill="#231F20" p-id="1360"></path>
					<path d="M561.619 206.364c-26.722-15.428-70.45-15.428-97.172 0l-192.309 111.03c-26.722 15.428-48.586 53.298-48.586 84.154v222.06c0 30.856 21.864 68.726 48.586 84.154l192.309 111.03c26.722 15.428 70.45 15.428 97.173 0l192.309-111.03c26.722-15.428 48.586-53.297 48.586-84.154v-222.06c0-30.856-21.864-68.726-48.586-84.154l-192.31-111.03z"
					 fill="#E0E0D1" p-id="1361"></path>
					<path d="M513.033 837.373c-19.621 0-38.119-4.438-52.089-12.519L268.632 713.827c-28.722-16.573-52.096-57.048-52.096-90.222V401.551c0-33.174 23.374-73.648 52.096-90.222l192.312-111.027c27.942-16.162 76.237-16.162 104.179 0l192.312 111.027c28.722 16.573 52.096 57.048 52.096 90.222v222.054c0 33.174-23.374 73.648-52.096 90.222L565.122 824.854c-13.971 8.081-32.468 12.519-52.089 12.519z m0-635.565c-17.197 0-33.201 3.78-45.077 10.629L275.645 323.465c-24.435 14.108-45.083 49.87-45.083 78.086v222.054c0 28.216 20.648 63.978 45.083 78.086l192.312 111.027c23.75 13.697 66.403 13.697 90.153 0l192.312-111.027c24.435-14.108 45.083-49.87 45.083-78.086V401.551c0-28.216-20.648-63.978-45.083-78.086L558.109 212.437c-11.875-6.848-27.88-10.629-45.076-10.629z"
					 fill="#E0E0D1" p-id="1362"></path>
					<path d="M513.033 482.075c-15.751 0-30.9-3.534-41.57-9.691L279.151 361.351c-8.28-4.78-13.033-10.574-13.033-15.909 0.007-5.321 4.753-11.122 13.033-15.895l192.312-111.034c10.67-6.164 25.819-9.697 41.57-9.697 15.751 0 30.9 3.534 41.57 9.691l192.312 111.041c8.28 4.773 13.026 10.574 13.033 15.895 0 5.335-4.753 11.129-13.033 15.909L554.603 472.378c-10.67 6.163-25.819 9.697-41.57 9.697zM483.699 811.349c-4.205 0-9.245-1.623-14.574-4.698L276.814 695.61c-22.538-13.005-41.577-45.981-41.577-72.005V401.551c0-6.198 1.267-20.614 12.978-20.614 4.198 0 9.239 1.63 14.574 4.712l192.312 111.027c22.531 13.012 41.57 45.987 41.57 72.005v222.061c0 7.253-1.568 13.204-4.424 16.758-2.111 2.63-4.83 3.849-8.548 3.849zM540.036 811.349c-11.711 0-12.978-14.409-12.978-20.607V568.681c0-26.017 19.039-58.993 41.57-72.012l192.312-111.02c5.335-3.082 10.375-4.712 14.574-4.712 11.711 0 12.978 14.416 12.978 20.614v222.054c0 26.024-19.039 58.999-41.577 72.005L554.603 806.644c-5.328 3.082-10.369 4.705-14.567 4.705z"
					 fill="#FFFFFF" p-id="1363"></path>
					<path d="M513.033 365.309c-17.738 0-32.729-9.095-32.729-19.861s14.991-19.867 32.729-19.867c17.737 0 32.729 9.102 32.729 19.867s-14.992 19.861-32.729 19.861zM276.642 657.998c-10.766 0-19.861-13.336-19.861-29.123 0-15.786 9.095-29.129 19.861-29.129s19.861 13.342 19.861 29.129-9.095 29.123-19.861 29.123zM742.411 657.998c-10.766 0-19.861-13.336-19.861-29.123 0-15.786 9.095-29.129 19.861-29.129s19.861 13.342 19.861 29.129c-0.001 15.787-9.096 29.123-19.861 29.123zM276.642 490.567c-10.766 0-19.861-13.336-19.861-29.123 0-15.786 9.095-29.129 19.861-29.129s19.861 13.342 19.861 29.129-9.095 29.123-19.861 29.123zM441.74 598.393c-10.766 0-19.861-13.342-19.861-29.129 0-15.786 9.095-29.129 19.861-29.129s19.867 13.342 19.867 29.129c0.001 15.787-9.101 29.129-19.867 29.129zM582.581 598.393c-10.766 0-19.861-13.342-19.861-29.129 0-15.786 9.095-29.129 19.861-29.129s19.867 13.342 19.867 29.129c0.001 15.787-9.101 29.129-19.867 29.129zM441.74 752.968c-10.766 0-19.861-13.342-19.861-29.129s9.095-29.129 19.861-29.129 19.867 13.342 19.867 29.129-9.101 29.129-19.867 29.129z"
					 fill="#4F5D73" p-id="1364"></path>
					<view class="cu-tag badge">6</view>
				</svg>


				<view class="content">
					<view class="text-grey">聊天室</view>
					<view class="text-gray text-sm flex">
						<view class="text-cut">
							点击加入聊天室
						</view>
					</view>
				</view>
				<!-- <view class="action">
					<view class="text-grey text-xs">23:59</view>
					<view class="cu-tag round bg-grey sm">5</view>
				</view> -->
			</view>


			<view class="cu-form-group">
				<view class="title">我是{{userinfo.gender?'男生':'女生'}}</view>
				<switch class='switch-sex' @change="changeGender" :class="userinfo.gender?'checked':''" :checked="userinfo.gender==1?true:false"></switch>
			</view>
		</view>
	</view>
</template>

<script>
	import {
		mapMutations,
		mapGetters
	} from 'vuex'
	export default {
		computed: {},
		data() {
			return {
				userinfo: {
					user_id: "",
					nickname: "点我修改用户名",
					gender: 0,
					avatar: 3,
				},



				avatar_url: "https://kustlove-1256941979.cos.ap-chengdu.myqcloud.com/avatars/blackgirl.png",
				nickname: "dashjay",

				avatars_list: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13],
				avatars_show: false,
				selected_avatar: 1,

				mate_show: false,

				editor_show: false,

				current_avatar: 3,
				current_nickname: "",
				current_mate: "",


				base_data: {
					content_type: -1, //登陆
					user_id: "" // 外部的用户id
				},

				MessageList: [],


			}
		},
		onShow() {

			let that = this;
			// 在收到消息的时候

		},
		onLoad() {
			this.LoadUserInfo()
		},

		onHide() {
			this.SendUserInfo();
		},
		methods: {
			// 1.修改性别
			changeGender(e) {
				this.userinfo.gender = e.detail.value ? 1 : 0;
			},

			GoChat() {
				// 跳转到聊天界面
				uni.navigateTo({
					url: "../chat/chat?userinfo=" + JSON.stringify(this.userinfo),
				})
			},

			// 修改头像
			EditAvatar() {
				this.avatars_show = !this.avatars_show;
			},

			// 选定头像
			chooseAvatar(e) {
				this.userinfo.avatar = e.currentTarget.dataset.aid;
				this.avatars_show = false;
				this.SendUserInfo();
			},
			// 修改用户名
			EditUsername() {
				this.editor_show = !this.editor_show;
			},
			// 确定昵称
			make_nickname() {
				this.editor_show = false;
				this.SendUserInfo();
			},

			SendUserInfo() {

				uni.setStorageSync('userinfo', this.userinfo);
			},
			LoadUserInfo() {
				let user_info = uni.getStorageSync('userinfo');
				if (user_info) {
					this.userinfo = user_info;
				}
			}
		},

	}
</script>

<style>
</style>
