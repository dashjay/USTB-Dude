package main

const (
	_row = 25
	_col = 25
	_suc = 5
)

func main() {
	player1 := &Robot{250}
	// player2 := new(Human)
	player2 := &Robot{500}
	play(player1, player2)
}
